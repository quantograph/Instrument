#ifndef Misc_h
#define Misc_h

#include <Arduino.h>

//void ShowBits(uint32_t value, String& s);
//void LogScreen(const char* line);

#endif
